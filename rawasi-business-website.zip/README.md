# رواسي — النسخة المحسنة
## الرفع
فك ضغط الحزمة وارفع محتوياتها كلها إلى جذر مستودع rawasi-engineering.
ارفع مجلدَي en وservices مع محتوياتهما، مع استبدال ملفات index.html وapp.js وstyle.css وsitemap.xml وREADME.md والإبقاء على .nojekyll.
من Settings > Pages اختر Deploy from a branch ثم main ثم / (root).
تابع نجاح عملية النشر في Actions.

## محتويات النسخة
- صفحة عربية وصفحة إنجليزية مستقلة داخل en.
- ست صفحات خدمات بالعربي وست بالإنجليزي.
- أسئلة شائعة، وتوضيح تنسيق متطلبات السلامة.
- صفحتا خصوصية بالعربي والإنجليزي.
- قائمة هاتف وواتساب ثابت ورابط مباشر لطلب الخدمة.
- المحتوى الأساسي موجود داخل HTML حتى عند تعطيل JavaScript.
- نموذج التواصل يجهز رسالة للعميل لإرسالها عبر واتساب أو البريد.

## إعداد الرابط
استُخدم https://mohammedragab99.github.io/rawasi-engineering/ كرابط النشر المتوقع.
إذا غيّرت اسم المستودع أو اشتريت دومينًا، استبدل هذا الرابط في ملفات HTML وفي sitemap.xml.
الخطوط الخارجية تحتاج اتصالًا بالإنترنت، مع خطوط بديلة تلقائية.

## تعديل التواصل
عدّل CONTACT في app.js لتحديث الروابط أثناء التشغيل.
حدّث أيضًا بيانات HTML والبيانات المنظمة لتظل صحيحة لمحركات البحث وعند تعطيل JavaScript.

## أجزاء تحتاج بيانات فعلية
لم تتم إضافة سجل تجاري أو حالة تأسيس أو أعمال سابقة أو شهادات أو أسماء عملاء أو سنوات خبرة دون معلومات مؤكدة.
يلزم توفير تلك البيانات قبل بناء أقسام الإثبات والفريق وملف الشركة PDF.
استقبال الطلبات تلقائيًا في خدمة نماذج يحتاج endpoint فعليًا. النموذج الحالي لا يحفظ الطلبات في خادم.
أسعار المعاينات والتغطية ومواعيد الرد تُتفق حسب الطلب؛ لا توجد وعود ثابتة على الموقع.
## التحقق
اجتاز JavaScript فحص الصياغة، وفُحصت الروابط المحلية والصفحات وبيانات JSON-LD.
لم يكتمل اختبار بصري في المتصفح.
## Business update
- Added separate careers pages and forms in Arabic and English.
- Customer requests include equipment, quantity and preferred timing.
- Added maintenance-plan options with scope and price agreed after assessment.
- Added printable service profiles (company-profile.html). Use Print > Save as PDF.
- Public forms still open WhatsApp or email drafts. The customer must send them.
- No automatic email receipts, server database, analytics or file-upload backend is connected.
- Attach photos and CV files in WhatsApp/email after opening the draft.
- Real case studies, commercial registration details, verified team qualifications and pricing require your records.
- This ZIP is the PUBLIC WEBSITE only. Upload its contents to the GitHub repository root.
- Do not upload enquiry backups or the separate internal toolkit to the public repository.
- Tested JavaScript syntax, local page links and bilingual message composition. Browser layout and print output still require review.
