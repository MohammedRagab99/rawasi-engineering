document.getElementById("careerForm").addEventListener("submit",event=>{
 event.preventDefault();
 const form=event.target;
 const lines=[document.documentElement.lang==="ar"?"طلب تعاون مع رواسي":"RAWASI collaboration application"];
 for(const input of form.querySelectorAll("input"))lines.push(input.previousElementSibling.textContent+": "+input.value.trim());
 const body=encodeURIComponent(lines.join("\n"));
 const email=event.submitter?.value==="email";
 document.getElementById("status").textContent=document.documentElement.lang==="ar"?"راجع الرسالة وأرسلها من التطبيق.":"Review and send the message in your app.";
 location.href=email?"mailto:mohammed.ragab@eng.asi.edu.eg?subject=RAWASI%20application&body="+body:"https://wa.me/201093597338?text="+body;
});